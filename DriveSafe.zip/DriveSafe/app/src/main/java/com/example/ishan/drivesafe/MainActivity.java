package com.example.ishan.drivesafe;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button buttonDriveSafe = (Button)findViewById(R.id.buttonSafeDrive);
        Button credits = (Button)findViewById(R.id.Credits);


        buttonDriveSafe.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,drive.class);
                startActivity(i);
            }
        });

        credits.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("About Us")
                        .setMessage("Swapnil AGE OF EMPIRES (#Provider) \nIshan \nGaurav \nDhruv \nAlumni (#Mobile provider)")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // continue with delete
                            }
                        })

                        .setIcon(android.R.drawable.ic_dialog_info)
                        .show();
            }
        });


    }
}
