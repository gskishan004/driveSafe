package com.example.ishan.drivesafe;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;



public class drive extends AppCompatActivity {

    int missedCallCounter=0;

    ArrayList<String> ph = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drive);

        Button buttonStopDrive = (Button)findViewById(R.id.buttonStopDriveSafe);
        final Button listButton = (Button)findViewById(R.id.listButton);

        final AudioManager am;
        am= (AudioManager) getBaseContext().getSystemService(Context.AUDIO_SERVICE);


        //For Silent mode
        am.setRingerMode(AudioManager.RINGER_MODE_SILENT);

        TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        // register PhoneStateListener

        PhoneStateListener callStateListener = new PhoneStateListener() {
            public void onCallStateChanged(int state, String incomingNumber)
            {   super.onCallStateChanged(state, incomingNumber);
                CheckBox sendMsg = (CheckBox)findViewById(R.id.replyCallers);
                //  React to incoming call.
                // If phone ringing
                if(state==TelephonyManager.CALL_STATE_RINGING)
                {
                    Toast.makeText(getApplicationContext(),"Phone Is Riging"+incomingNumber, Toast.LENGTH_LONG).show();

                    Calendar c = Calendar.getInstance();

                    int hours = c.get(Calendar.HOUR);
                    int min = c.get(Calendar.MINUTE);
                    //adding ph no to array list
                    ph.add(incomingNumber+"  at  "+ hours +":"+min );
                    missedCallCounter++;
                    listButton.setText(missedCallCounter+" "+ "MISSED CALLS");


                    String message = "Hey stop calling im DRIVING !";

                    SmsManager sms = SmsManager.getDefault();
                    if(sendMsg.isChecked()) {
                        Toast.makeText(getApplicationContext(), "msg sent", Toast.LENGTH_LONG).show();
                        sms.sendTextMessage(incomingNumber, null, message, null, null);
                    }
                }

                if(state==TelephonyManager.CALL_STATE_IDLE)
                {
                   // Toast.makeText(getApplicationContext(),"phone is neither ringing nor in a call", Toast.LENGTH_LONG).show();
                }
            }
        };
        telephonyManager.listen(callStateListener,PhoneStateListener.LISTEN_CALL_STATE);


        buttonStopDrive.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(drive.this,MainActivity.class);
                //For Normal mode
                am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                missedCallCounter=0;
                startActivity(i);
            }
        });

        listButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent inew = new Intent(drive.this,ListMissedCall.class);
                inew.putExtra("phone",ph);
                startActivity(inew);
            }
        });

    }
}
