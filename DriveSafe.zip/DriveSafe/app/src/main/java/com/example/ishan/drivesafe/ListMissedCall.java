package com.example.ishan.drivesafe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;

public class ListMissedCall extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_missed_call);

        Intent intent = getIntent();
        ArrayList<String> newph = intent.getStringArrayListExtra("phone");

        //reversing the list
        Collections.reverse(newph);

        ListView lv = (ListView)findViewById(R.id.listView);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this,android.R.layout.simple_list_item_1,
                newph
        );

        lv.setAdapter(arrayAdapter);


    }
}
